.Features  ul.a {
    list-style-type: circle;
  }
  
  .Features ul.b {
    list-style-type: square;
  }
  
    ol.c {
    list-style-type: upper-roman;
  }
  
  .Features ol.d {
    list-style-type: lower-alpha;
  }
  .Features {
    background-color:#e4eaeb;
    padding: 40px;
  }
  .right-section-1 {
      float: right;
  }
  /* Style all font awesome icons */
  .fa {
      padding: 15px;
    font-size: 230px;
    width: 100px;
    
    text-align: center;
    text-decoration: none;
    margin: 5px 12px;
   border-radius: 33px;
    }
    
    /* Add a hover effect if you want */
    .fa:hover {
      opacity: 0.7;
    }
    
    /* Set a specific color for each brand */
    
    .facebook img{
      width: 82px;
      height: 82px; 
      padding: 12px;
    }
    
    .twitter img{
      width: 82px;
      height: 82px; 
      padding: 12px; 
    }
    
   
    
    .linkedin img{
      width: 82px;
    height: 82px;
    padding: 12px;
    }
    
    
    
    .instagram img{
     
    width: 82px;
    height: 82px;
    padding: 12px;
    }
    .social-media {
     padding: 14px;
    }
    footer {
        background-color: gray;
       
    }